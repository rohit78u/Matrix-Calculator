# Matrix Calculator Web App

A Flask-based web application for performing various matrix operations with a clean, responsive interface.

![Matrix Calculator Demo](demo-screenshot.png) *Screenshot placeholder - add your actual screenshot later*

## Features

- Perform matrix operations: Addition, Subtraction, Multiplication
- Advanced operations: Transpose, Determinant, Inverse
- Interactive matrix input grid
- Real-time results display
- Responsive design works on desktop and mobile
- Modern UI with clean styling

## Demo

To see the app in action:

1. Clone this repository
2. Install requirements: `pip install -r requirements.txt`
3. Run the app: `python app.py`
4. Open in browser: `http://localhost:5000`

**Demo Steps:**
1. Enter matrix values in the input grids
2. Select an operation from the dropdown
3. Click "Calculate" to see results
4. View formatted matrix output with operation symbols

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/Matrix-Calculator.git
cd Matrix-Calculator
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python app.py
```

## Technologies Used

- Python 3
- Flask (Web Framework)
- HTML5 & CSS3
- JavaScript (for interactive matrix input)

## Project Structure

```
Matrix-Calculator/
├── app.py                # Main Flask application
├── matrix_calculator.py  # Matrix operation logic
├── requirements.txt      # Dependencies
├── static/
│   └── css/
│       └── style.css     # Styling
└── templates/
    └── index.html        # Main interface
```

## Screenshot Instructions

To add your actual demo screenshot:
1. Take a screenshot of the running application
2. Save as `demo-screenshot.png` in the project root
3. The image will automatically appear in the README

## License

MIT License - Free for personal and educational use
