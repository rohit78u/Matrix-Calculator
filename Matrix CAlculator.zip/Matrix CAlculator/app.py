from flask import Flask, render_template, request, redirect, url_for
import numpy as np

app = Flask(__name__)

class MatrixCalculator:
    @staticmethod
    def add_matrices(matrix_a, matrix_b):
        return matrix_a + matrix_b

    @staticmethod
    def subtract_matrices(matrix_a, matrix_b):
        return matrix_a - matrix_b

    @staticmethod
    def multiply_matrices(matrix_a, matrix_b):
        return np.matmul(matrix_a, matrix_b)

    @staticmethod
    def transpose_matrix(matrix):
        return matrix.T

    @staticmethod
    def determinant(matrix):
        return np.linalg.det(matrix)

    @staticmethod
    def inverse_matrix(matrix):
        return np.linalg.inv(matrix)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        matrix_a = np.array(eval(request.form['matrix_a']))
        matrix_b = np.array(eval(request.form['matrix_b']))
        operation = request.form['operation']
        
        if operation == 'add':
            result = MatrixCalculator.add_matrices(matrix_a, matrix_b)
        elif operation == 'subtract':
            result = MatrixCalculator.subtract_matrices(matrix_a, matrix_b)
        elif operation == 'multiply':
            result = MatrixCalculator.multiply_matrices(matrix_a, matrix_b)
        elif operation == 'transpose_a':
            result = MatrixCalculator.transpose_matrix(matrix_a)
        elif operation == 'transpose_b':
            result = MatrixCalculator.transpose_matrix(matrix_b)
        elif operation == 'determinant_a':
            result = MatrixCalculator.determinant(matrix_a)
        elif operation == 'determinant_b':
            result = MatrixCalculator.determinant(matrix_b)
        elif operation == 'inverse_a':
            result = MatrixCalculator.inverse_matrix(matrix_a)
        elif operation == 'inverse_b':
            result = MatrixCalculator.inverse_matrix(matrix_b)
        
        return render_template('index.html', 
                            matrix_a=matrix_a.tolist(),
                            matrix_b=matrix_b.tolist(),
                            operation=operation,
                            result=result.tolist() if hasattr(result, 'tolist') else result)

    return render_template('index.html', result=None)

if __name__ == "__main__":
    app.run(debug=True)
