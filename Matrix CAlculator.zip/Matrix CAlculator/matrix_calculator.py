import numpy as np

class MatrixCalculator:
    def __init__(self):
        self.matrix_a = None
        self.matrix_b = None

    def input_matrix(self, name):
        print(f"\nEnter matrix {name}:")
        rows = int(input("Number of rows: "))
        cols = int(input("Number of columns: "))
        matrix = []
        print("Enter elements row-wise (separated by space):")
        for i in range(rows):
            while True:
                row = input(f"Row {i+1}: ").strip().split()
                if len(row) == cols:
                    try:
                        row = [float(x) for x in row]
                        matrix.append(row)
                        break
                    except ValueError:
                        print("Please enter valid numbers")
                else:
                    print(f"Please enter exactly {cols} elements")
        return np.array(matrix)

    def add_matrices(self):
        if self.matrix_a.shape != self.matrix_b.shape:
            print("Matrices must have same dimensions for addition")
            return None
        return self.matrix_a + self.matrix_b

    def subtract_matrices(self):
        if self.matrix_a.shape != self.matrix_b.shape:
            print("Matrices must have same dimensions for subtraction")
            return None
        return self.matrix_a - self.matrix_b

    def multiply_matrices(self):
        if self.matrix_a.shape[1] != self.matrix_b.shape[0]:
            print("Number of columns in first matrix must match rows in second matrix")
            return None
        return np.matmul(self.matrix_a, self.matrix_b)

    def transpose_matrix(self, matrix):
        return matrix.T

    def determinant(self, matrix):
        if matrix.shape[0] != matrix.shape[1]:
            print("Matrix must be square for determinant calculation")
            return None
        return np.linalg.det(matrix)

    def inverse_matrix(self, matrix):
        if matrix.shape[0] != matrix.shape[1]:
            print("Matrix must be square for inverse calculation")
            return None
        try:
            return np.linalg.inv(matrix)
        except np.linalg.LinAlgError:
            print("Matrix is singular (determinant is 0), cannot compute inverse")
            return None

    def run(self):
        print("Matrix Calculator")
        print("----------------")
        self.matrix_a = self.input_matrix("A")
        self.matrix_b = self.input_matrix("B")

        while True:
            print("\nOperations:")
            print("1. Add matrices")
            print("2. Subtract matrices")
            print("3. Multiply matrices")
            print("4. Transpose matrix A")
            print("5. Transpose matrix B")
            print("6. Determinant of matrix A")
            print("7. Determinant of matrix B")
            print("8. Inverse of matrix A")
            print("9. Inverse of matrix B")
            print("0. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                result = self.add_matrices()
            elif choice == '2':
                result = self.subtract_matrices()
            elif choice == '3':
                result = self.multiply_matrices()
            elif choice == '4':
                result = self.transpose_matrix(self.matrix_a)
            elif choice == '5':
                result = self.transpose_matrix(self.matrix_b)
            elif choice == '6':
                result = self.determinant(self.matrix_a)
            elif choice == '7':
                result = self.determinant(self.matrix_b)
            elif choice == '8':
                result = self.inverse_matrix(self.matrix_a)
            elif choice == '9':
                result = self.inverse_matrix(self.matrix_b)
            elif choice == '0':
                print("Exiting...")
                break
            else:
                print("Invalid choice")
                continue

            if result is not None:
                print("\nResult:")
                print(result)

if __name__ == "__main__":
    calculator = MatrixCalculator()
    calculator.run()
